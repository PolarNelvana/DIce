﻿(Japanese, UTF-8)

XScreenSaveWin
==============

これは XScreenSaver for Windows (XScreenSaverWin) です。このソフトウェアは、
Jamie Zawinski さんによる、XScreenSaver 5.22 (Windows 以外の OS) に基づいて
います。Windows への移植は、片山博文 MZ によって行われました。

移植状況は STATUS.txt でご確認ください。ライセンス情報は、LICENSE.txt をご
参照下さい。Windows XP/Vista/Server 2003/7/10 で動作します。

一度 XScreenSaverWin をインストールしたら、スクリーンセーバーのインストール
は、メインプログラム「xscreensaver.exe」から行えます。

!!! 注意 !!
-----------

すべてのスクリーンセーバーを一度にインストールすることはできません。
あなたは、一つのフォルダーにそんなにたくさんの.scrファイルを直接置くべき
ではありません。それは.scrのインストールを失敗させます。
一度にインストールできる数には制限があります（Windows の制限）。

  ------------------------------------------------------------------------
  XScreenSaver (オリジナル; Windows以外用)
  http://www.jwz.org/xscreensaver/

  GitHub XScreenSaverWin repository
  https://github.com/katahiromz/XScreenSaverWin

  片山博文MZ (かたやまひろふみエムゼッド)
  katayama.hirofumi.mz@gmail.com
  ------------------------------------------------------------------------

 * 片山博文MZ (katahiromz) 軍隊蟻
 * ホームページ: http://katahiromz.web.fc2.com/
 * 掲示板: http://katahiromz.bbs.fc2.com/
 * メール: katayama.hirofumi.mz@gmail.com
