XScreenSaveWin
==============

This is XScreenSaver for Windows (XScreenSaverWin). This software was
based on XScreenSaver 5.22 (for non-Windows OS) by Jamie Zawinski.
Porting to Windows was mostly done by Katayama Hirofumi MZ.

Check STATUS.txt for porting status. Check LICENSE.txt for licensing
information. It works on Windows XP/Vista/Server 2003/7/10.

Once you installed XScreenSaverWin, then you can install a screensaver
from the main program "xscreensaver.exe".

!!! WARNING !!!
---------------

You cannot install all the screensavers at once.
You mayn't put so many .scr files in one folder directly.
It fails .scr installation.
There's limitation of Windows in the numbers of installables at once.

  ------------------------------------------------------------------------
  XScreenSaver (original; for non-Windows)
  http://www.jwz.org/xscreensaver/

  GitHub XScreenSaverWin repository
  https://github.com/katahiromz/XScreenSaverWin

  Katayama Hirofumi MZ (Japanese) katayama.hirofumi.mz@gmail.com
  ------------------------------------------------------------------------

 * Katayama Hirofumi MZ (katahiromz) [ARMYANT] 
 * Homepage:
 * http://katahiromz.web.fc2.com/eindex.html
 * BBS: http://katahiromz.bbs.fc2.com/
 * E-Mail: katayama.hirofumi.mz@gmail.com
