
#ifndef __TEAPOT_H__
#define __TEAPOT_H__

extern int unit_teapot (int density, int wire_p);

#endif /* __TEAPOT_H__ */
