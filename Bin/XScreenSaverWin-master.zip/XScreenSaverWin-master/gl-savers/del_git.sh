rm -Rf .git
