#pragma once
#ifndef WINVER
#define WINVER 0x0600           // Windows Vista
#endif

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600     // Windows Vista
#endif

#ifndef _WIN32_WINDOWS
#define _WIN32_WINDOWS 0x0410   // Windows 98
#endif

#ifndef _WIN32_IE
#define _WIN32_IE 0x0700        // Internet Explorer 7.0
#endif
