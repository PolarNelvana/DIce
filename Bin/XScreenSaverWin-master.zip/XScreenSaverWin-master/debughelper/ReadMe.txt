This is a debug helper for Win32 screen saver (debughelper).

Usage:
0. Build debughelper and a Win32 screen saver of debug version.
1. Start up debughelper.
2. Copy the debugging parameters string ("/p ?????") by Ctrl+C.
3. Set breakpoints if you want.
4. Start debugging the screen saver with using the debugging parameters.
5. The screen saver will run in the debughelper window.
